'use client';
import React, {createContext, useContext} from 'react'

const Context = useContext([]);
export default Context;